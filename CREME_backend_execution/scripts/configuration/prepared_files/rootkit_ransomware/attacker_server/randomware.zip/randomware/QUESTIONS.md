Questions
=========

1. What type of ELF file is this?
2. What is the value of `Elf64_Ehdr.e_version` in this file?
3. What is the segment type that contains the section `.init_array`?
4. What is the virtual address of the entrypoint of the binary?
5. What is the decryption key?
6. What algorithm is used for encryption?
