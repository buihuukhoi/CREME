#!/bin/bash

cd ./randomware
gcc -std=gnu99 randomware.c -o randomware
./randomware
