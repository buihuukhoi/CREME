#!/bin/bash

cd ./EVIL_RABBIT
make
chmod 555 evil_rabbit_launch_script.sh evil_rabbit.so
./evil_rabbit_launch_script.sh -y
