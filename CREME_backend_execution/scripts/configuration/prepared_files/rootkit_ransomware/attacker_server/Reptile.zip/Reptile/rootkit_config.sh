#!/bin/bash

cd ./Reptile
expect <<EOF
spawn make config
expect "*(NEW) " {send "n\r"}
expect "*(NEW) " {send "\r"}
expect "*(NEW) " {send "\r"}
expect "*(NEW) " {send "\r"}
expect "*(NEW) " {send "\r"}
expect "*(NEW) " {send "\r"}
expect "*(NEW) " {send "\r"}
expect "*(NEW) " {send "\r"}
expect "*(NEW) " {send "\r"}
expect "*(NEW) " {send "\r"}
expect "*:~$ " {send "exit\n"}
EOF
make
make install
